package com.example.ch9_ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

//ViewPager 의 항목(화면)을 구성하는 adapter...


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}