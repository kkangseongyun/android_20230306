package com.example.ch11_receiver;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ch11_receiver.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //퍼미션... 허락...
        ActivityResultLauncher launcher = registerForActivityResult(
          new ActivityResultContracts.RequestMultiplePermissions(),
          isGranted -> {
              if(isGranted.containsValue(false)){
                  Toast.makeText(this, "permission denied",Toast.LENGTH_SHORT).show();
              }else {
                  noti();
              }
          }
        );
    }
}