package com.example.ch13_provider;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ch13_provider.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    //우리가 만드는 파일 경로..
    String filePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //gallery launcher....
        ActivityResultLauncher<Intent> launcher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //gallery 목록에서 사진 선택해서 되돌아 올대...
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inSampleSize = 10;//10분의 1로 줄여서 로딩...
                        try {
                            //사진의 식별자가 url 형식으로 넘어온다.. url 은 gallery app provider 연동 url
                            //식별자만 뽑아서.. 파일 경로만 획득도 가능하기는 하지만..
                            //gallery 에서 inputstream 도 제공..

                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
        );
    }
}